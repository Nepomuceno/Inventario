﻿namespace Sirius.Coletor.Base
{
    public enum TipoUsuario
    {
        Coletor = 1,
        Administrador = 2
    }
}
