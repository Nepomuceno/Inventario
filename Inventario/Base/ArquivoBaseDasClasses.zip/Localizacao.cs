﻿namespace Sirius.Coletor.Base
{
    public class Localizacao
    {
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public TipoLeitura TipoLeitura { get; set; }
    }
}