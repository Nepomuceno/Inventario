namespace Sirius.Coletor.Base
{
    public enum TipoLeitura
    {
        Unica = 1,
        Multipla = 2
    }
}