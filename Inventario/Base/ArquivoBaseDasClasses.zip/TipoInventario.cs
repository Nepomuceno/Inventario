﻿namespace Sirius.Coletor.Base
{
    public enum TipoInventario
    {

    }
}